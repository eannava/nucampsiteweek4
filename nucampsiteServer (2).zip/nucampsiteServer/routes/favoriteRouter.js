const express = require('express');
var authenticate = require('../authenticate');
const cors = require('./cors');
const Favorite = require('../models/favorite');

const favoriteRouter = express.Router();

favoriteRouter.route('/')
.options(cors.corsWithOptions, (req, res) => res.sendStatus(200))

.get(cors.cors, (req, res, next) => {
    Favorites.findOne({user: req.user._id})
    .populate('user')
    .populate('campsite')
    .then(campsite => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(favorites);
    })
    .catch(err => next(err));
})

.post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {    Campsite.create(req.body)
    Favorite.findOne({user: req.user._id })
    .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
        Favorite.findOne({user: req.user._id})
            .then(favorites => {
                if(favorites){
                    req.body.forEach(fav => {
                        if(!favorites.campsites.includes(fav._id)){
                            favorites.campsites.push(fav._id)
                        }
                    })
                    favorites.save()
                        .then(favorite => {
                            res.statusCode = 200;
                            res.setHeader('Content-Type', 'applications/json');
                            res.json(favorite);
                        })
                        .catch(err => next(err))
                }else{
                    Favorite.create(req.body)
                    .then(favorites => {
                        req.body.forEach(fav => {
                        if(!favorites.campsites.includes(fav._id)){
                            favorites.campsites.push(fav._id)
                        }
                    })
                    favorites.save()
                        .then(favorite => {
                            res.statusCode = 200;
                            res.setHeader('Content-Type', 'applications/json');
                            res.json(favorite);
                        })
                        .catch(err => next(err))
                    })
                }
            })
            .catch(err => next(err));
    })
})
.put(cors.corsWithOptions, authenticate.verifyUser,  (req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /favorites');
})
         
.delete(cors.corsWithOptions, authenticate.verifyUser,  (req, res, next) => {
    Favorites.findOneAndDelete({"user": req.user._id})
    .then((response) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(response);
    }, (err) => next(err))
    .catch((err) => next(err)); 
});






favoriteRouter.route('/:campsiteId')
.options(cors.corsWithOptions, (req, res) => res.sendStatus(200))

.get(cors.cors, (req, res, next) => {
    
    Favorites.findOne({user: req.user._id})
    .populate('user')
    .populate('campsite')
    .then(campsite => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(favorites);
    })
    .catch(err => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser,  (req, res, next) => {    Campsite.create(req.body)
    Favorite.findOne({user: req.user._id})
    .then(favorites => {
        if(favorites){
            req.body.forEach(fav => {
                if(!favorites.campsites.includes(fav._id)){
                    favorites.campsites.push(fav._id)
                }
            })
            favorites.save()
                .then(favorite => {
                    res.statusCode = 200;
                    res.setHeader('Content-Type', 'applications/json');
                    res.json(favorite);
                })
                .catch(err => next(err))
        }else{
            res.end('That campsite is already in the list of favorites!')
        }
    })
    .catch(err => next(err));
})
.put(cors.corsWithOptions, authenticate.verifyUser,  (req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /favorites');
})
.delete(cors.corsWithOptions, authenticate.verifyUser,  (req, res, next) => {
    Favorites.findOne({user: req.user._id})
    .then((favorite) => {
        if (favorite) {            
            index = favorite.campsites.indexOf(req.params.campsiteId);
            if (index >= 0) {
                favorite.campsites.splice(index);
                favorite.save()
                .then((favorite) => {
                    console.log('Favorite Deleted ', favorite);
                    res.statusCode = 200;
                    res.setHeader('Content-Type', 'application/json');
                    res.json(favorite);
                }, (err) => next(err));
            } else {
                    err = new Error('no Favorites to Delete');
                    err.status = 404;
                    return next(err);
                }
            }
        })
    })









module.exports = {favoriteRouter};